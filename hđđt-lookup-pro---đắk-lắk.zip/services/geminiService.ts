
import { GoogleGenAI } from "@google/genai";
import { TaxRecord } from "../types";

/**
 * Lấy phân tích từ AI Gemini.
 * Sử dụng mô hình gemini-3-flash-preview để phân tích rủi ro thuế chuyên nghiệp.
 */
export const getTaxInsights = async (record: TaxRecord): Promise<string> => {
  const apiKey = process.env.API_KEY;
  
  if (!apiKey) {
    return "Hệ thống chưa cấu hình AI Key. Vui lòng liên hệ quản trị viên.";
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    
    const prompt = `
      Hãy đóng vai một chuyên gia phân tích rủi ro thuế giàu kinh nghiệm của Việt Nam.
      Phân tích dữ liệu sau của doanh nghiệp (Mã số thuế: ${record.MST}):
      - Tên doanh nghiệp: ${record.Ten}
      - Số lượng hóa đơn đã xuất: ${record.SL}
      - Tiền thuế GTGT phát sinh: ${new Intl.NumberFormat('vi-VN').format(record.Thue)} VND
      - Tổng doanh thu lũy kế: ${new Intl.NumberFormat('vi-VN').format(record.TongTien)} VND

      Nhiệm vụ của bạn:
      1. Đánh giá quy mô doanh nghiệp dựa trên doanh thu (Siêu nhỏ/Nhỏ/Vừa/Lớn).
      2. Nhận xét về tần suất xuất hóa đơn so với doanh thu (có bất thường hay không).
      3. Đưa ra một lời khuyên về tuân thủ pháp luật thuế cho cán bộ kiểm tra (tối đa 3 câu súc tích).
      
      Phản hồi bằng tiếng Việt chuyên nghiệp, lịch sự.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        temperature: 0.3,
        topP: 0.9,
      }
    });

    return response.text || "AI không thể đưa ra nhận định vào lúc này.";
  } catch (error) {
    console.error("Gemini Insight Error:", error);
    return "Không thể kết nối với trí tuệ nhân tạo để phân tích.";
  }
};
