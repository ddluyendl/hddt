
/**
 * Advanced CSV Row Parser
 * Handles quoted fields, escaped quotes, and trimming.
 */
export const parseCSVRow = (row: string): string[] => {
  const result: string[] = [];
  let currentCell = '';
  let inQuotes = false;
  
  for (let i = 0; i < row.length; i++) {
    const char = row[i];
    if (char === '"') {
      if (inQuotes && row[i + 1] === '"') {
        currentCell += '"'; 
        i++; 
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      result.push(currentCell.trim());
      currentCell = '';
    } else {
      currentCell += char;
    }
  }
  result.push(currentCell.trim());
  return result;
};

/**
 * Intelligent Number Parser
 * Robustly handles Vietnamese thousands separators (dots) and decimal separators.
 * Fixes issues where 9.545.455 was parsed as 9.545 or 10.
 */
export const parseNumber = (str: string | undefined): number => {
  if (!str) return 0;
  let s = str.trim().replace(/\s/g, '');
  if (s === '' || s === '-') return 0;

  // Identify positions of separators
  const lastDot = s.lastIndexOf('.');
  const lastComma = s.lastIndexOf(',');

  // Case: Both dot and comma exist (e.g., 1.234.567,89 or 1,234,567.89)
  if (lastDot !== -1 && lastComma !== -1) {
    if (lastComma > lastDot) {
      // VN style: 1.234.567,89 -> remove dots, change comma to dot
      return parseFloat(s.replace(/\./g, '').replace(',', '.'));
    } else {
      // US style: 1,234,567.89 -> remove commas
      return parseFloat(s.replace(/,/g, ''));
    }
  }

  // Case: Only commas
  if (lastComma !== -1) {
    const commaCount = (s.match(/,/g) || []).length;
    if (commaCount > 1) {
      // Multiple commas -> definitely thousands separators
      return parseFloat(s.replace(/,/g, ''));
    }
    // Single comma: Guess if it's decimal or thousands
    const parts = s.split(',');
    // In tax data, a separator followed by exactly 3 digits is almost always a thousands separator
    if (parts[1].length === 3) return parseFloat(s.replace(/,/g, ''));
    // Otherwise treat as decimal
    return parseFloat(s.replace(',', '.'));
  }

  // Case: Only dots (The problematic case for 9.545.455)
  if (lastDot !== -1) {
    const dotCount = (s.match(/\./g) || []).length;
    if (dotCount > 1) {
      // Multiple dots -> definitely thousands separators (e.g., 9.545.455)
      return parseFloat(s.replace(/\./g, ''));
    }
    // Single dot: Guess if it's decimal or thousands
    const parts = s.split('.');
    // If followed by 3 digits (and not just .000), likely thousands
    if (parts[1].length === 3 && parts[1] !== '000') return parseFloat(s.replace(/\./g, ''));
    // Otherwise treat as decimal (e.g., 665000468.0)
    return parseFloat(s);
  }

  return parseFloat(s) || 0;
};
